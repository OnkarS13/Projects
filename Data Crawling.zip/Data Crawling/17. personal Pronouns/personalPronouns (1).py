#!/usr/bin/env python
# coding: utf-8

# In[2]:


import os
import re

def count_personal_pronouns(text):
    # create a list of personal pronouns
    personal_pronouns = ["I", "we", "my", "ours", "us"]
    # use regex to find the matches of personal pronouns in the text
    personal_pronoun_matches = re.findall(r'\b(?:{})\b'.format('|'.join(personal_pronouns)), text, re.IGNORECASE)
    # return the count of personal pronouns
    return len(personal_pronoun_matches)

# directory path where text files are stored
directory_path = "/Users/sonavaneonkar/Desktop/5. Tokanized_files"

# iterate through all the files in the directory
for filename in os.listdir(directory_path):
    # read the text file
    with open(os.path.join(directory_path, filename), "r", encoding='latin-1') as file:
        text = file.read()
    # calculate the count of personal pronouns
    pronoun_count = count_personal_pronouns(text)
    # print the count of personal pronouns for each file
    print("{}: {}".format(filename, pronoun_count))


# In[ ]:




