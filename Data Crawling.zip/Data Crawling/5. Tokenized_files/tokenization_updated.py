#!/usr/bin/env python
# coding: utf-8

# In[13]:


import nltk
import os

# Define the directory containing the text files
dir = '/Users/sonavaneonkar/Desktop/Text_Files_after_cleaning_using_stop_words'

# Download the necessary NLTK resources
nltk.download('punkt')

# Define the characters to remove
remove_chars = [",", ".", "'", ":", '"', "1", "2", "3","4", "5", "6", "7", "8", "9", "0"]

for file in os.listdir(dir):
    # Check if the file is a text file
    if file.endswith('.txt'):
        with open(os.path.join(dir, file), 'r') as f:
            text = f.read()
            # Tokenize the text
            tokens = nltk.word_tokenize(text)
            # Remove the specified characters
            tokens = [token for token in tokens if token not in remove_chars]
            # Create a new file with the same name but a different file extension
            new_file = file.replace('.txt', '_tokens.txt')
            with open(os.path.join(dir, new_file), 'w') as out:
                # Write the tokens to the new file, each on a new line and separated by a comma
                out.write('"' + '",\n"'.join(tokens) + '"')
                
print("Tokenization and new file creation completed!")


# In[ ]:




