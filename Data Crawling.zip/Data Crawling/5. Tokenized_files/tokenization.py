#!/usr/bin/env python
# coding: utf-8

# In[3]:


import nltk
from nltk.tokenize import word_tokenize
import os

# Define the directory containing the text files
directory = "/Users/sonavaneonkar/Desktop/Text_Files_after_cleaning_using_stop_words"

# Iterate through all files in the directory
for filename in os.listdir(directory):
    if filename.endswith(".txt"):
        # Open the file and read its contents
        with open(os.path.join(directory, filename), "r") as file:
            text = file.read()

        # Tokenize the text
        tokens = word_tokenize(text)

        # Create a new file with the tokens separated by single quotes
        with open(os.path.join(directory, "tokens_" + filename), "w") as file:
            file.write("'".join(tokens))


# In[ ]:




