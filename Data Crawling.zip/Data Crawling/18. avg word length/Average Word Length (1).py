#!/usr/bin/env python
# coding: utf-8

# In[7]:


import os

# set the path to the directory containing text files
directory_path = "/Users/sonavaneonkar/Desktop/5. Tokanized_files"

# loop through all the files in the directory
for filename in os.listdir(directory_path):
    # read the text file
    with open(os.path.join(directory_path, filename), "r", encoding='latin-1') as file:
        text = file.read()
        
    # split the text into words
    words = text.split()
    
    # calculate the total number of characters in the text
    total_characters = sum(len(word) for word in words)
    
    # calculate the total number of words
    total_words = len(words)
    
    # calculate the average word length
    average_word_length = total_characters / total_words
    
    # print the average word length for the current file
    print(f"Average word length in file {filename}: {average_word_length}")


# In[ ]:




