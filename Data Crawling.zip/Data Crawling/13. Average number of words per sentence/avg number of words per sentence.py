#!/usr/bin/env python
# coding: utf-8

# In[1]:


import os
from nltk import sent_tokenize, word_tokenize

def avg_words_per_sentence(file_path):
    with open(file_path, 'r') as f:
        text = f.read()
    sentences = sent_tokenize(text)
    words = word_tokenize(text)
    return len(words) / len(sentences)

directory = '/Users/sonavaneonkar/Desktop/5. Tokanized_files'
for filename in os.listdir(directory):
    if filename.endswith('.txt'):
        file_path = os.path.join(directory, filename)
        avg_words = avg_words_per_sentence(file_path)
        print(f'{filename}: {avg_words}')


# In[ ]:




