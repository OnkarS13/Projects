#!/usr/bin/env python
# coding: utf-8

# In[13]:


import requests
from bs4 import BeautifulSoup

url = "https://insights.blackcoffer.com/ai-in-healthcare-to-improve-patient-outcomes/"

response = requests.get(url)
soup = BeautifulSoup(response.text, "html.parser")

# Find the main container of the article
article_container = soup.find("div", class_="td-post-content")

if article_container:
    # Extract the text of the article
    article_text = article_container.get_text()

    # Remove any extra whitespace
    article_text = article_text.strip()

    print(article_text)
else:
    print("Article container not found")


# In[2]:


pip install nltk


# In[3]:


pip install requests


# In[4]:


pip install bs4


# In[5]:


pip install tokenizers


# In[6]:


pip install nltk


# In[7]:


import nltk
nltk.download('averaged_perceptron_tagger')


# In[9]:


import nltk
nltk.download('all')


# In[10]:


import requests
from bs4 import BeautifulSoup
import nltk
from nltk.tokenize import sent_tokenize, word_tokenize

url = "https://insights.blackcoffer.com/ai-in-healthcare-to-improve-patient-outcomes/"

response = requests.get(url)
soup = BeautifulSoup(response.text, "html.parser")

# Extract all the text from the webpage
text = soup.get_text()

# Perform sentence tokenization
sentences = sent_tokenize(text)

# Perform word tokenization on each sentence
word_list = [word_tokenize(sent) for sent in sentences]

# Perform part-of-speech tagging on each sentence
pos_tags = [nltk.pos_tag(sent) for sent in word_list]

print(pos_tags)


# In[ ]:




