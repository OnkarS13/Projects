#!/usr/bin/env python
# coding: utf-8

# In[1]:


import os

# set the path to the directory containing the text files
directory_path = "/Users/sonavaneonkar/Desktop/5. Tokanized_files"

# get a list of all text files in the directory
files = [f for f in os.listdir(directory_path) if f.endswith('.txt')]

# define a function to count the number of syllables in a word
def count_syllables(word):
    vowels = "aeiouyAEIOUY"
    word = word.lower()
    word = word.strip(".:;?!)(")
    if word[-2:] == "ed":
        return 0
    if word[-2:] == "es":
        return 0
    if word[-1:] == "e":
        return 0
    if word[-3:] == "ing":
        return 0
    count = 0
    for i in range(len(word)):
        if word[i] in vowels:
            count += 1
    return count

# loop through each text file
for file_name in files:
    # set the path to the text file
    file_path = os.path.join(directory_path, file_name)

    # read the text file
    with open(file_path, 'r') as file:
        text = file.read()

    # split the text into words
    words = text.split()

    # initialize the syllable count
    syllable_count = 0

    # loop through each word and add the syllable count to the total syllable count
    for word in words:
        syllable_count += count_syllables(word)

    print("Total syllables in file '{}': {}".format(file_name, syllable_count))


# In[ ]:




