#!/usr/bin/env python
# coding: utf-8

# In[7]:


import os
import nltk
from nltk.corpus import stopwords

# download the stopwords package
nltk.download('stopwords')

# set the path to the directory containing the text files
directory_path = "/Users/sonavaneonkar/Desktop/5. Tokanized_files"

# initialize the stop words
stop_words = set(stopwords.words('english'))

# iterate through the files in the directory
for file_name in os.listdir(directory_path):
    if file_name.endswith(".txt"):
        # build the file path
        file_path = os.path.join(directory_path, file_name)
        # read the text file
        with open(file_path, 'r') as file:
            text = file.read()
        # tokenize the text
        words = nltk.word_tokenize(text)
        # remove stop words
        cleaned_words = [word for word in words if word.lower() not in stop_words]
        # count the cleaned words
        cleaned_word_count = len(cleaned_words)
        print("Total cleaned words in file "+file_name+" :", cleaned_word_count)


# In[8]:





# In[ ]:




