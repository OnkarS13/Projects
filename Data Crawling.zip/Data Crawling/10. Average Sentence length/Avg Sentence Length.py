#!/usr/bin/env python
# coding: utf-8

# In[1]:


import os
import nltk
from nltk.tokenize import sent_tokenize

def avg_sentence_length(text_path):
    with open(text_path, 'r') as f:
        text = f.read()
    sentences = sent_tokenize(text)
    words = nltk.word_tokenize(text)
    return len(words) / len(sentences)

directory = '/Users/sonavaneonkar/Desktop/5. Tokanized_files'
for filename in os.listdir(directory):
    if filename.endswith('.txt'):
        text_path = os.path.join(directory, filename)
        avg_sentence_len = avg_sentence_length(text_path)
        print(f'Average sentence length for {filename}: {avg_sentence_len}')


# In[ ]:




